EURO HR Android Project - Mobile se APK build

यह तैयार APK नहीं, Android Studio project source है। इस ZIP में GitHub Actions build workflow भी है ताकि कंप्यूटर के बिना मोबाइल browser से APK build कराया जा सके।

मोबाइल से:
1. github.com पर account बनाएं/Sign in करें।
2. + > New repository चुनें; नाम EURO-HR रखें; Public या Private चुनें; Create repository करें।
3. ZIP को फोन में extract करें। GitHub वेबसाइट पर repository में Add file > Upload files से extracted project के सभी folders/files upload करें। छिपा हुआ .github folder और उसके अंदर workflows/build-apk.yml भी upload होना चाहिए।
4. Commit changes दबाएँ।
5. Repository के Actions tab में जाएँ।
6. "Build EURO HR APK" workflow चुनें और Run workflow दबाएँ।
7. Build सफल होने पर नीचे Artifacts में EURO-HR-debug-APK.zip डाउनलोड करें।
8. ZIP extract करें; app-debug.apk खोलें। Android पूछे तो इस स्रोत से install की अनुमति दें।

नोट:
- APK build के लिए GitHub Actions account/repository पर उपलब्ध होना चाहिए; GitHub sign-in और internet जरूरी हैं।
- यह निजी attendance tracker है, कंपनी के official HR/server से जुड़ा नहीं है।
- अभी Employee ID/name app profile में login authentication के रूप में लागू नहीं हैं। यह source project केवल attendance diary बनाता है; password login implemented नहीं है।
- Attendance records app/browser local storage में रहते हैं।
